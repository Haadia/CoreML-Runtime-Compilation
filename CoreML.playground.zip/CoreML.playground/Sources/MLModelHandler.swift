import Foundation
import CoreML
import UIKit

public func buffer(from image: UIImage) -> CVPixelBuffer? {
    let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
    var pixelBuffer : CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(image.size.width), Int(image.size.height), kCVPixelFormatType_32ARGB, attrs, &pixelBuffer)
    guard (status == kCVReturnSuccess) else {
        return nil
    }
    
    CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
    let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)
    
    let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
    let context = CGContext(data: pixelData, width: Int(image.size.width), height: Int(image.size.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)
    
    context?.translateBy(x: 0, y: image.size.height)
    context?.scaleBy(x: 1.0, y: -1.0)
    
    UIGraphicsPushContext(context!)
    image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
    UIGraphicsPopContext()
    CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
    
    return pixelBuffer
}



public class MLModelHandler {
    
    public init() {
        print("Initialized")
    }
    
    public func compileModel(path: URL) -> URL? {
        guard let compiledURL = try? MLModel.compileModel(at: path) else {
            print("Error in compiling model.")
            return nil
        }
        return compiledURL
    }
    
    
    public func compileModelAndPredict(path: URL, image: UIImage) {
        let compiledURL = compileModel(path: path)
        
        if let compiledURL = compiledURL {
            // 1
            guard let model = try? MLModel(contentsOf: compiledURL) else {
                print("Error in getting model")
                return
            }
            
            UIGraphicsBeginImageContextWithOptions(CGSize(width: 224, height: 224), true, 2.0)
            image.draw(in: CGRect(x: 0, y: 0, width: 224, height: 224))
            let newImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            // 2
            let imageBuffer = buffer(from: newImage!)
            
            do {
                // 3
                let result = try model.prediction(from: GoogleNetPlacesInput(sceneImage: imageBuffer!))
                
                // 4
                let label = result.featureValue(for: "sceneLabel")?.stringValue
                print(label)
            } catch {
                print(error)
            }
        }
    }

}

