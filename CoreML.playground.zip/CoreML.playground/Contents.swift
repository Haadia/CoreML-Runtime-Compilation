import UIKit
import CoreML
import PlaygroundSupport

let handler = MLModelHandler()
//URL of Apple's ml model
let fileURL = URL(string: "https://docs-assets.developer.apple.com/coreml/models/GoogLeNetPlaces.mlmodel")

//Destination url, in our case Playground Shared Data Directory
let documentsDirectory = playgroundSharedDataDirectory.appendingPathComponent("GoogleNetPlaces.mlmodel")

let task = URLSession.shared.downloadTask(with: fileURL!) { localURL, urlResponse, error in
    if let localURL = localURL {
        
        let fileManager = FileManager.default
        
        do {
            
            if fileManager.fileExists(atPath: documentsDirectory.path) {
                print("Already downloaded")
            }
            else {
            //Copy from temporary location to custom location.
            try fileManager.copyItem(at: localURL, to: documentsDirectory)
            print("downloaded")
            }
            
            let image = UIImage(named: "forest.jpg")
            handler.compileModelAndPredict(path: documentsDirectory, image: image!)
                        
        }
        catch {
            print("Error in copying to playground's documents directory \(error)")
        }
    }
    else {
        print("Unable to download. \(error?.localizedDescription)")
    }
}

task.resume()
